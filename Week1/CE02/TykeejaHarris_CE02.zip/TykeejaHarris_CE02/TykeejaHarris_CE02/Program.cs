﻿using System;

namespace TykeejaHarris_CE02
{
    class Program
    {
        static void Main(string[] args)
        {
            CourseManagerClass newTracker = new CourseManagerClass();

        }
    }
}
